﻿  function LiEmail()
      {
        document.getElementById("divEmail").style.display="block";
        document.getElementById("divTel").style.display="none";
        document.getElementById("Email").style.background="url(Themes/Skin_Default/Images/reggg.jpg) center no-repeat";
        document.getElementById("Email").style.color="#FFF";
        document.getElementById("Mobile").style.background="#FFF";
        document.getElementById("Mobile").style.color="#D40000";
      }

    function LiMobile()
      {
        document.getElementById("divEmail").style.display="none";
        document.getElementById("divTel").style.display="block";
        document.getElementById("Email").style.background="#FFF";
        document.getElementById("Email").style.color="#D40000";
        document.getElementById("Mobile").style.background="url(Themes/Skin_Default/Images/reggg.jpg) center no-repeat";
        document.getElementById("Mobile").style.color="#FFF";
      }