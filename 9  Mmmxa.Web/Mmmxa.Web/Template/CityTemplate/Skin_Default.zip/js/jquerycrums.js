// JavaScript Document
// <![CDATA[

$(function(){
    $(".jd_menu > li").each(function(i){
    $(this).addClass("mainmenu" + (i+1));    
    });});
// ]]>